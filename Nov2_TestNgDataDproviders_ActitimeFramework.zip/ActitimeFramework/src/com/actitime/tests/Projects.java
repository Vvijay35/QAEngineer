package com.actitime.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.actitime.base.BaseClass;
import com.actitime.utils.CommonUtils;

public class Projects extends BaseClass {
	
	//@Test(groups = { "smoke", "projects","projects_001" })
	@Test
	public static void projects_001() throws InterruptedException, IOException
	{
		writeLogsToFile("*************** Starting the test case projects_001*********************");		
		CommonUtils.loginToActitime();
		writeLogsToFile("Chcking for the logout link post login");
		boolean logoutLink = false;
		
		try {
			logoutLink = driver.findElement(By.xpath(getLocatorDataFromExcel("Home", "Logout_link"))).isDisplayed();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		
		Assert.assertTrue(logoutLink, "The logout link not seen projects_001 Failed");
		
		writeLogsToFile("The logout link is displayed....login successFul");
		writeResultsToFile("projects_001", "Pass");
		
		
		
		
	}

}
