package com.actitime.tests;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.actitime.base.BaseClass;
import com.actitime.utils.CommonUtils;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class Login extends BaseClass {
	
	
	//@Parameters({ "username","password" })
	//@Test(dataProvider = "logindata") // to take the data from the data provider present in the same class
	//@Test(dataProvider = "logindatafromexcel",dataProviderClass = com.actitime.dataproviders.DataProviders.class)
	@Test
	public static void login_001() throws InterruptedException, IOException
	{
		CommonUtils.loginToActitime();
		writeInfoLogs("Chcking for the logout link post login");
		boolean logoutLink = false;	
		logoutLink = driver.findElement(By.xpath(getLocatorDataFromMap("Home", "Logout_link"))).isDisplayed();		
		Assert.assertTrue(logoutLink, "The logout link not seen Login_001 Failed");	
		
	}
	
	
	//@Test(dependsOnMethods = { "login_001"}) // login_002 will only run if login_001 is Passed else it will skipped...	
	//@Test(priority = 1) // Runs this test case as first priority	
	//@Test(groups = { "regression", "login","login_002" })
	
	@Test
	public static void login_002() throws InterruptedException, IOException
	{
				
		CommonUtils.loginToActitime();
		writeInfoLogs("Chcking for the logout link post login");
		boolean logoutLink = false;
		logoutLink = driver.findElement(By.xpath(getLocatorDataFromMap("Home", "Logout_link"))).isDisplayed();
		Assert.assertFalse(logoutLink, "The Logout link not seen Login_002 Failed");
		
		
	}
	
	// Soft Assertion will not stop if any assertion fails... it will show all the failed assertions at the end...
	//@Test
	public static void testNGSoftAssertionEx()
	{
		SoftAssert softAssert = new SoftAssert();		
		System.out.println("*** test case two started ***");
		// This assertion will pass
		softAssert.assertEquals("Hello", "Hello", "First soft assert Passed");
		System.out.println("hard assert success....");
		// This assertion will fail
		softAssert.assertTrue("Hello".equals("hello"), "Second soft assert failed");
		// This assertion will fail
		softAssert.assertTrue("Welcome".equals("welcomeeee"), "Third soft assert failed");
		System.out.println("*** test case two executed successfully ***");
		softAssert.assertEquals("Hello", "Hello", "First soft assert Passed");
		softAssert.assertAll();
	}
	
	@Test
	public static void login_003() throws InterruptedException, IOException
	{
				
		CommonUtils.loginToActitime();
		writeInfoLogs("Chcking for the logout link post login");
		boolean logoutLink = false;
		logoutLink = driver.findElement(By.xpath(getLocatorDataFromMap("Home", "Logout_link"))).isDisplayed();
		Assert.assertTrue(logoutLink, "The Logout link not seen Login_003 Failed");
		
		
	}
	
	/*
	 * public static void main(String[] args) {
	 * 
	 * 
	 * System.out.println(" Starting the Report Demo");
	 * 
	 * File f = new File("./src/test/results/ereport.html");
	 * 
	 * // Create the object of ExtentSparkReporter class ExtentSparkReporter
	 * reporter = new ExtentSparkReporter (f);
	 * 
	 * // Creating the object of Extent Reports class ExtentReports extent = new
	 * ExtentReports();
	 * 
	 * // Attaching the reporter to report extent.attachReporter(reporter);
	 * 
	 * // Creating the object of ExtentTest to strat reporting ExtentTest logger =
	 * extent.createTest("SampleExtentReportTest");
	 * 
	 * logger.log(Status.INFO, " Starting to Log in to Extent Report");
	 * 
	 * logger.log(Status.INFO, " Starting to Log second to Extent Report");
	 * 
	 * logger.log(Status.PASS, "The Test Case is Pass");
	 * 
	 * extent.flush();
	 * 
	 * 
	 * }
	 */


}
