package com.actitime.tests;

import java.io.IOException;

public class Runner {

	public static void main(String[] args) throws InterruptedException, IOException {

		Login.login_001();		
		Customer.customer_001();
		Projects.projects_001();
		

	}

}
