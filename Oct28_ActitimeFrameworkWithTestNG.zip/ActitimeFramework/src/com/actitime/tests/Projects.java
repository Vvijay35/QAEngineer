package com.actitime.tests;

import java.io.IOException;

import org.openqa.selenium.By;

import com.actitime.base.BaseClass;
import com.actitime.utils.CommonUtils;

public class Projects extends BaseClass {
	
	
	public static void projects_001() throws InterruptedException, IOException
	{
		writeLogsToFile("*************** Starting the test case projects_001*********************");
		launchActiTimeApplication();
		CommonUtils.loginToActitime();
		writeLogsToFile("Chcking for the logout link post login");
		boolean logoutLink = false;
		
		try {
			logoutLink = driver.findElement(By.xpath(getLocatorDataFromExcel("Home", "Logout_link"))).isDisplayed();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		
		if(logoutLink)
		{
			writeLogsToFile("The logout link is displayed....login successFul");
			writeResultsToFile("projects_001", "Pass");
		}
		else
		{
			writeResultsToFile("projects_001", "Fail");
			captureScreenShotOnFailure("projects_001");
		}
		
		
		closeBrowser();
		
		
	}

}
