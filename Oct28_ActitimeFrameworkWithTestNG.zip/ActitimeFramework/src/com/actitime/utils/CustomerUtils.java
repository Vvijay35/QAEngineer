package com.actitime.utils;

import com.actitime.base.BaseClass;

public class CustomerUtils extends BaseClass {

}
